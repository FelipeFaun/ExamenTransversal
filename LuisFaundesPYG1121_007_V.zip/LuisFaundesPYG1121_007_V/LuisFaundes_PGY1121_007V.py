#Felipe Faundes-PGY1121-007V
import numpy as np

#Salir
def salir_menu():
    print ("¡Hasta Pronto!")
    
#Datos
disponibilidad_depto = np.zeros((10, 4), dtype=bool)
departamentos = [
]
clientes = {}
# Opcion 2 
def mostrar_disponibilidad_depto():
    print("Departamentos Disponibles:")
    disponibilidad = np.where(disponibilidad_depto, "[X]", "[ ]")
    print(disponibilidad)
    

# Opcion 1
def seleccionar_depto():
    rut = input("Ingrese su RUT: ")
    nombre = input("Ingrese su nombre completo: ")
    telefono = input("Ingrese su número de teléfono: ")
    email = input("Ingrese su dirección de email: ")

    fila = int(input("Ingrese la fila del departamento: "))
    columna = int(input("Ingrese la columna del departamento: "))


    if disponibilidad_depto[fila, columna]:
        print("El departamento seleccionado no está disponible. Por favor, escoje otro.")
    else:
        disponibilidad_depto[fila, columna] = True
        depto_seleccionado = departamentos[columna + fila * disponibilidad_depto.shape[1]]
        clientes[rut] = {"nombre": nombre, "telefono": telefono, "email": email, "departamento": depto_seleccionado}
        print("Departamento seleccionado correctamente.")

#Opcion 4
def ver_ganancias():
    numero_depto = int(input("Ingrese el número de departamento seleccionado: "))

    depto_seleccionado = None
    for depto in depto:
        if depto["numero"] == numero_depto:
            depto_seleccionado = depto
            break

    if depto_seleccionado:
        print("Detalles del departamento seleccionado:")
        print("Número de departamento:", depto_seleccionado["numero"])
        print("Precio:", depto_seleccionado["precio"])
    else:
        print("Departamento no encontrado.")

#Opcion 3
def ver_clientes():
    print("Clientes que han comprado un departamento:")
    for rut, cliente in clientes.items():
        print("RUT:", rut)
        print("Nombre:", cliente["nombre"])
        print("Teléfono:", cliente["telefono"])
        print("Email:", cliente["email"])
        print("Departamento seleccionado:", cliente["departamento"])
        print()
# Bucle principal
while True:
    print("----- Casa Feliz -----")
    print("1. Comprar departamento")
    print("2. Mostrar departamentos disponibles")
    print("3. Ver listado de compradores")
    print("4. Mostrar ganancias totales")
    print("5. Salir")

    opcion = input("Ingrese la opción deseada: ")

    if opcion == "1":
        seleccionar_depto()
    elif opcion == "2":
        mostrar_disponibilidad_depto()
    elif opcion == "3":
        ver_clientes()
    elif opcion == "4":
        ver_ganancias()
    elif opcion == "5":
        salir_menu()
        break
    else:
        print("Opción inválida. Por favor, ingrese nuevamente.")